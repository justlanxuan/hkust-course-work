# search.py
import heapq
import random

from problem import SearchProblem


class Search:
    """
    General search class providing reference implementations for DFS and A*.
    """

    @staticmethod
    def depth_first_search(problem: SearchProblem):
        """
        Implements Depth-First Search (DFS) using a stack (Last-In-First-Out).

        TODO:
        - Use a stack to manage the search frontier.
        - Maintain a set of visited states to avoid re-exploration.
        - Use `problem.get_start_state()` to get the initial state.
        - Use `problem.is_goal_state(state)` to check if the goal is reached.
        - Use `problem.get_successors(state)` to expand the search tree.

        Implementation Notes:
        - Yield each visited state to allow step-by-step visualization.
        - Return a tuple: (path from start to goal, set of visited states).
        - If no path is found, return (None, visited).
        """
        pass  # TODO: Implement DFS here

    @staticmethod
    def heuristic(goals, state):
        """
        Heuristic function used in A* search.

        TODO:
        - Implement a heuristic to estimate the cost from the current state to the goal.
        - A simple option is the Manhattan distance to the nearest uncollected goal.
        """
        pass  # TODO: Implement heuristic function here

    @staticmethod
    def a_star_search(problem: SearchProblem):
        """
        Implements A* search using a priority queue.

        TODO:
        - Use a priority queue (heap) to prioritize states based on f = g + h.
        - g(n): The actual cost from the start state to the current state.
        - h(n): The heuristic estimate of the remaining cost to the goal.
        - Use `problem.get_start_state()` to get the initial state.
        - Use `problem.is_goal_state(state)` to check if the goal is reached.
        - Use `problem.get_successors(state)` to expand the search tree.

        Implementation Notes:
        - Yield each visited state to allow step-by-step visualization.
        - Return a tuple: (path from start to goal, set of visited states).
        - If no path is found, return (None, visited).
        """
        pass  # TODO: Implement A* search here

    @staticmethod
    def random_search(problem: SearchProblem):
        """
        A simple random walk search algorithm.

        This method demonstrates an uninformed search strategy where the agent
        moves randomly without considering an optimal path.

        Implementation:
        - Start from `problem.get_start_state()`.
        - Randomly select a successor from `problem.get_successors(state)`.
        - Continue until reaching a goal state.

        Returns:
        - A tuple: (random path from start to goal, set of visited states).
        - If no path is found, return (None, visited).
        """
        start = problem.get_start_state()
        if problem.is_goal_state(start):
            return [], {start}

        visited = set()
        state = start
        path = []

        while True:
            visited.add(state)
            yield state  # Yield the current state for visualization

            if problem.is_goal_state(state):
                return path, visited  # Return the discovered path

            successors = problem.get_successors(state)
            if not successors:
                break  # No available moves, terminate search

            # Randomly select the next move from available successors
            next_state, _ = random.choice(successors)

            # Prevent getting stuck by revisiting the last state too frequently
            if len(path) > 1 and next_state == path[-1]:
                continue  # Try another random move instead of oscillating

            path.append(next_state)
            state = next_state  # Move to the new state

        return None, visited  # No valid path found
